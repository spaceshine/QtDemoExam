#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "adminwindow.h"
#include "ui_adminwindow.h"
#include "emplwindow.h"
#include "ui_emplwindow.h"
#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#include <QMessageBox>

using namespace std;

QString username="", userlogin="-", userrole="";

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    aw = new AdminWindow();
    rw = new EmplWindow();
    connect(aw, &AdminWindow::firstWindow, this, &MainWindow::show);
    connect(rw, &EmplWindow::firstWindow, this, &MainWindow::show);
}

MainWindow::~MainWindow()
{
    //cout << "closing 1-st window" << endl;
    delete rw;
    delete aw;
    delete ui;
}


void MainWindow::on_actReg_triggered()
{
//    aw->show();
//    hide();
}

void MainWindow::on_actMain_triggered()
{
    if (userrole == "работник"){
        rw->updateInfo();
        rw->show(); // Показываем окно работника
        this->close(); // Закрываем основное окно
    } else if (userrole == "администратор") {
        aw->updateInfo();
        aw->show(); // Показываем второе окно
        this->close(); // Закрываем основное окно
    } else {
        QMessageBox::warning(this, "Предупреждение", "Вы не вошли в аккаунт",
                             QMessageBox::Ok);
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    string s, substr;
    bool isright=false, isenter=false;
    int c;
    ifstream input_file;
    input_file.open("data.csv");
    //cout << "InpOpen: " << input_file.good() << endl;
    while (getline(input_file, s)){
        stringstream ss(s);
        c=0;
        while (ss.good()) {
            getline(ss, substr, ',');
            QString sstr=QString::fromStdString(substr);
            if (c==0){
                isright = ui->edtLogin->text() == sstr;
                if (isright) userlogin = sstr;
            }
            if (c==1)
                isright = isright && ui->edtPassword->text() == sstr;
            if (isright && c==2){
                userrole = sstr.toLower();
                if (userrole == "работник"){
                    isenter = true;
                    getline(ss, substr, ',');
                    getline(ss, substr, ',');
                    username = QString::fromStdString(substr);
                    rw->updateInfo();
                    rw->show(); // Показываем окно работника
                    this->close(); // Закрываем основное окно
                } else if (userrole == "администратор"){
                    isenter = true;
                    aw->show();
                    aw->updateInfo();
                    this->close();
                }
            }
            c++;
        }
    }
    input_file.close();
    if (isenter == false){
        QMessageBox::warning(this, "Ошибка", "Неверные данные для входа",
                             QMessageBox::Ok);
    }
}
