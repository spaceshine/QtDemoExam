#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <bits/stdc++.h>

using namespace std;

extern QString userlogin;

string header = "Id;Last_name;Name;Login;Password;Role;";

AdminWindow::AdminWindow(QWidget *parent) :
    QMainWindow(parent),
    admui(new Ui::AdminWindow)
{
    admui->setupUi(this);

    admui->tblEmpl->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    admui->tblEmpl->verticalHeader()->setVisible(true);
    admui->tblEmpl->setColumnCount(5);
    admui->tblEmpl->setHorizontalHeaderLabels(QStringList() << "Логин" << "Пароль" << "Роль" << "Имя" << "Фамилия");

    updateTable();
}

AdminWindow::~AdminWindow()
{
    updateCSV();

    delete admui;
}

void AdminWindow::updateCSV()
{
    ofstream output_file;
    output_file.open("data.csv");

    //cout << "Opened: " << output_file.good() << endl;
    output_file << header << endl;
    QString s;
    string stdstr;
    for (int i=0; i < admui->tblEmpl->rowCount(); i++){
        s.setNum(i); s+= ';';
        s += admui->tblEmpl->item(i, 4)->text() + ';';
        s += admui->tblEmpl->item(i, 3)->text() + ';';
        s += admui->tblEmpl->item(i, 0)->text() + ';';
        s += admui->tblEmpl->item(i, 1)->text() + ';';
        s += admui->tblEmpl->item(i, 2)->text() + ';';
        s.chop(1);
        stdstr = s.toStdString();
        output_file << stdstr << endl;
    }

    output_file.close();
}

void AdminWindow::updateTable()
{
    admui->tblEmpl->setRowCount(1);
    string s, substr;
    int c, r;
    vector<string> v, vv;
    ifstream input_file;
    input_file.open("data.csv");

    getline(input_file, s);
    while (getline(input_file, s)){
        v.clear(); vv.clear();
        stringstream ss(s);
        c=0;
        r=admui->tblEmpl->rowCount()-1;
        getline(ss, substr, ';');

        while (ss.good()) {
            getline(ss, substr, ';');
            v.push_back(substr);
        }

        vv.push_back(v.at(2));
        vv.push_back(v.at(3));
        vv.push_back(v.at(4));
        vv.push_back(v.at(1));
        vv.push_back(v.at(0));

        for(string &s : vv){
            QString sstr=QString::fromStdString(s);;
            QTableWidgetItem *pCell = admui->tblEmpl->item(r, c);
            if(!pCell)
            {
                pCell = new QTableWidgetItem;
                admui->tblEmpl->setItem(r, c, pCell);
            }
            pCell->setText(sstr);
            c++;
        }
        admui->tblEmpl->insertRow(admui->tblEmpl->rowCount());
    }
    admui->tblEmpl->removeRow(admui->tblEmpl->rowCount()-1);
    input_file.close();
}

void AdminWindow::editRow(int r){
    QString s;
    for (int c=0; c<5; c++){
        QTableWidgetItem *pCell = admui->tblEmpl->item(r, c);
        if(!pCell)
        {
            pCell = new QTableWidgetItem;
            admui->tblEmpl->setItem(r, c, pCell);
        }
        switch (c){
        case 0:
            s = admui->edtLogin->text(); break;
        case 1:
            s = admui->edtPassword->text(); break;
        case 2:
            s = admui->edtRole->text(); break;
        case 3:
            s = admui->edtName->text(); break;
        case 4:
            s = admui->edtSurname->text(); break;
        }
        pCell->setText(s);
    }
}

void AdminWindow::on_actReg0_triggered()
{
    this->close();      // Закрываем окно
    emit firstWindow(); // И вызываем сигнал на открытие главного окна
}

void AdminWindow::on_btnAdd_clicked()
{
    int r=admui->tblEmpl->rowCount();
    admui->tblEmpl->insertRow(r);

    AdminWindow::editRow(r);
    AdminWindow::updateCSV();
}


void AdminWindow::on_tblEmpl_itemSelectionChanged()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int i = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    //cout << i << endl;

    admui->edtLogin->setText(admui->tblEmpl->item(i, 0)->text());
    admui->edtPassword->setText(admui->tblEmpl->item(i, 1)->text());
    admui->edtRole->setText(admui->tblEmpl->item(i, 2)->text());
    admui->edtName->setText(admui->tblEmpl->item(i, 3)->text());
    admui->edtSurname->setText(admui->tblEmpl->item(i, 4)->text());
}


void AdminWindow::on_btnReset_clicked()
{
    admui->edtLogin->setText("");
    admui->edtPassword->setText("");
    admui->edtRole->setText("");
    admui->edtName->setText("");
    admui->edtSurname->setText("");
}


void AdminWindow::on_btnEdit_clicked()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int r = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    AdminWindow::editRow(r);
    AdminWindow::updateCSV();
}


void AdminWindow::on_btnDel_clicked()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int r = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    admui->tblEmpl->removeRow(r);
    AdminWindow::updateCSV();
}

void AdminWindow::updateInfo(){
    userlogin = userlogin.isEmpty() ? "-" : userlogin;
    admui->lblAccLogin->setText(acctempl+userlogin);

    QFont font("Segoe UI", 12);
    QFontMetrics fm(font);
    admui->line->setMinimumWidth(3+fm.horizontalAdvance(acctempl+userlogin));
}

void AdminWindow::on_btnReturn_clicked()
{
    this->close();
    emit firstWindow();
}

