#include "adminwindow.h"
#include "ui_adminwindow.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <bits/stdc++.h>

using namespace std;

extern QString userlogin;

AdminWindow::AdminWindow(QWidget *parent) :
    QMainWindow(parent),
    admui(new Ui::AdminWindow)
{
    admui->setupUi(this);

    admui->tblEmpl->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    admui->tblEmpl->verticalHeader()->setVisible(true);
    admui->tblEmpl->setColumnCount(4);
    admui->tblEmpl->setHorizontalHeaderLabels(QStringList() << "Логин" << "Пароль" << "Роль" << "Имя сотрудника");

    updateTable();
}

AdminWindow::~AdminWindow()
{
    updateCSV();

    delete admui;
}

void AdminWindow::updateCSV()
{
    ofstream output_file;
    output_file.open("data.csv");

    //cout << "Opened: " << output_file.good() << endl;
    QString s;
    string stdstr;
    for (int i=0; i < admui->tblEmpl->rowCount(); i++){
        s="";
        for (int j=0; j < 4; j++){
            s += admui->tblEmpl->item(i, j)->text() + ',';
        }
        s.chop(1);
        stdstr = s.toStdString();
        output_file << stdstr << endl;
    }

    output_file.close();
}

void AdminWindow::updateTable()
{
    admui->tblEmpl->setRowCount(1);
    string s, substr;
    int c, r;
    ifstream input_file;
    input_file.open("data.csv");
    //cout << "InpOpen: " << input_file.good() << endl;
    while (getline(input_file, s)){
        //cout << s << endl;
        stringstream ss(s);
        c=0;
        r=admui->tblEmpl->rowCount()-1;
        while (ss.good()) {
            getline(ss, substr, ',');
            QString sstr=QString::fromStdString(substr);;
            QTableWidgetItem *pCell = admui->tblEmpl->item(r, c);
            if(!pCell)
            {
                pCell = new QTableWidgetItem;
                admui->tblEmpl->setItem(r, c, pCell);
            }
            pCell->setText(sstr);
            c++;
            //cout << substr << endl;
        }
        admui->tblEmpl->insertRow(admui->tblEmpl->rowCount());
    }
    admui->tblEmpl->removeRow(admui->tblEmpl->rowCount()-1);
    input_file.close();
}

void AdminWindow::editRow(int r){
    QString s;
    for (int c=0; c<4; c++){
        QTableWidgetItem *pCell = admui->tblEmpl->item(r, c);
        if(!pCell)
        {
            pCell = new QTableWidgetItem;
            admui->tblEmpl->setItem(r, c, pCell);
        }
        switch (c){
        case 0:
            s = admui->edtLogin->text(); break;
        case 1:
            s = admui->edtPassword->text(); break;
        case 2:
            s = admui->edtRole->text(); break;
        case 3:
            s = admui->edtName->text(); break;
        }
        pCell->setText(s);
    }
}

void AdminWindow::on_actReg0_triggered()
{
    this->close();      // Закрываем окно
    emit firstWindow(); // И вызываем сигнал на открытие главного окна
}

void AdminWindow::on_btnAdd_clicked()
{
    int r=admui->tblEmpl->rowCount();
    admui->tblEmpl->insertRow(r);

    AdminWindow::editRow(r);
    AdminWindow::updateCSV();
}


void AdminWindow::on_tblEmpl_itemSelectionChanged()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int i = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    //cout << i << endl;

    admui->edtLogin->setText(admui->tblEmpl->item(i, 0)->text());
    admui->edtPassword->setText(admui->tblEmpl->item(i, 1)->text());
    admui->edtRole->setText(admui->tblEmpl->item(i, 2)->text());
    admui->edtName->setText(admui->tblEmpl->item(i, 3)->text());
}


void AdminWindow::on_btnReset_clicked()
{
    admui->edtLogin->setText("");
    admui->edtPassword->setText("");
    admui->edtRole->setText("");
    admui->edtName->setText("");
}


void AdminWindow::on_btnEdit_clicked()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int r = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    AdminWindow::editRow(r);
    AdminWindow::updateCSV();
}


void AdminWindow::on_btnDel_clicked()
{
    if (admui->tblEmpl->selectionModel()->selectedIndexes().isEmpty())
        return;
    int r = admui->tblEmpl->selectionModel()->selectedIndexes().at(0).row(); //строка
    admui->tblEmpl->removeRow(r);
    AdminWindow::updateCSV();
}

void AdminWindow::updateInfo(){
    userlogin = userlogin.isEmpty() ? "-" : userlogin;
    admui->lblAccLogin->setText(acctempl+userlogin);

    QFont font("Segoe UI", 12);
    QFontMetrics fm(font);
    admui->line->setMinimumWidth(3+fm.horizontalAdvance(acctempl+userlogin));
}

void AdminWindow::on_btnReturn_clicked()
{
    this->close();
    emit firstWindow();
}

