#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include <QMainWindow>

namespace Ui {
class AdminWindow;
}

class AdminWindow : public QMainWindow
{
    Q_OBJECT

public:
    Ui::AdminWindow *admui;
    explicit AdminWindow(QWidget *parent = nullptr);
    ~AdminWindow();
    void updateInfo();

    QString acctempl = "Аккаунт: ";

private slots:
    void on_actReg0_triggered();

    void on_btnAdd_clicked();

    void on_tblEmpl_itemSelectionChanged();

    void updateCSV();

    void updateTable();

    void editRow(int r);

    void on_btnReset_clicked();

    void on_btnEdit_clicked();

    void on_btnDel_clicked();

    void on_btnReturn_clicked();

signals:
    void firstWindow();  // Сигнал для первого окна на открытие
};

#endif // ADMINWINDOW_H
