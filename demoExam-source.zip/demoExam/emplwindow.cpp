#include "emplwindow.h"
#include "ui_emplwindow.h"
#include "mainwindow.h"
#include <iostream>

using namespace std;

extern QString username, usersurname;

EmplWindow::EmplWindow(QWidget *parent) :
    QMainWindow(parent),
    rui(new Ui::EmplWindow)
{
    rui->setupUi(this);
    cout << username.toStdString() << endl;
}

EmplWindow::~EmplWindow()
{
    delete rui;
}

void EmplWindow::updateInfo(){
    rui->lblHello->setText(username+' '+usersurname+hellotempl);
}

void EmplWindow::on_btnReturn_clicked()
{
    this->close();
    emit firstWindow();
}


void EmplWindow::on_actReg1_triggered()
{
    this->close();
    emit firstWindow();
}

