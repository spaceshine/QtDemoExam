#ifndef EMPLWINDOW_H
#define EMPLWINDOW_H

#include <QMainWindow>

namespace Ui {
class EmplWindow;
}

class EmplWindow : public QMainWindow
{
    Q_OBJECT

public:
    Ui::EmplWindow *rui;
    explicit EmplWindow(QWidget *parent = nullptr);
    ~EmplWindow();
    QString hellotempl = ", приветствуем вас на виртуальной системе торгов!";

    void updateInfo();

private:
    //

signals:
    void firstWindow();  // Сигнал для первого окна на открытие
private slots:
    void on_btnReturn_clicked();
    void on_actReg1_triggered();
};

#endif // EMPLWINDOW_H
